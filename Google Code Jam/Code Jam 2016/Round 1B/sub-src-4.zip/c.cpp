#include "bits/stdc++.h"
using namespace std;

int main()
{
	std::ios::sync_with_stdio(false);
	#ifndef ONLINE_JUDGE
		freopen("C-small-attempt1.in","r",stdin);
		freopen("C-small-out1.in","w",stdout);
	#endif
	int te;cin>>te;
	int n;
	std::vector<string> fir,sec;
	map<string,int>allfir,allsec;
	std::map<string, bool> unfir,unsec;
	int cheat=0;
	for(int t=1;t<=te;t++)
	{
		cheat=0;
		cin>>n;
		allsec.clear();
		allfir.clear();
		fir=std::vector<string> (n);
		sec=std::vector<string> (n);
		unfir.clear();
		unsec.clear();
		for(int i=0;i<n;i++)
		{
			cin>>fir[i]>>sec[i];
			allfir[fir[i]]++;
			allsec[sec[i]]++;
		}

		for(int i=0;i<n;i++)
		{
			if(allfir[fir[i]]>1 && allsec[sec[i]]<=1)
			{
				unfir[fir[i]]=1;
			}
			if(allfir[fir[i]]<=1 && allsec[sec[i]]>1)
			{
				unsec[sec[i]]=1;
			}
		}

		for(int i=0;i<n;i++)
		{
			if(allfir[fir[i]]>1 && allsec[sec[i]]>1 )
			{
				cheat++;
				//cout<<fir[i]<<" "<<sec[i]<<endl;
				if(unfir[fir[i]] && unsec[sec[i]])
				{
					//allfir[fir[i]]--;allsec[sec[i]]--;
				}
				else if(unfir[fir[i]])
				{
					allsec[sec[i]]--;	
				}
				else if(unsec[sec[i]])
				{
					allfir[fir[i]]--;	
				}
				else
				{
					allfir[fir[i]]--;allsec[sec[i]]--;
				}
			}
		}
		
		cout<<"Case #"<<t<<": "<<cheat<<endl;

	}
}